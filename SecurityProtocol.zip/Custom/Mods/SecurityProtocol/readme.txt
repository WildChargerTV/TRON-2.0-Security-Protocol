DISCLAIMER: Although TRON 2.0: Security Protocol can be installed and ran without causing any game instability, it is only available as a separate package. Please do not attempt to load any Retail game saves while the mod is active. I am not responsible for any lost or corrupted saves.

TRON 2.0: Security Protocol, by WildCharger

Thank you for your interest in TRON 2.0: Security Protocol. At present, the mod is being entirely reorganized as a project, and wil be restarted from the ground up. All updates following this one will be considered part of that new project.

The version of TRON 2.0: Security Protocol currently available is a cosmetic change - upon booting the game and arriving at the main menu, an ICP Regular will have replaced Jet in the disc-throwing animation.

Future updates will be available soon. Thank you.